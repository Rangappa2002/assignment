const express = require("express");
const bodyParser = require("body-parser");
require("dotenv").config({ path: "./config/dev.env"});
const myRouter = require("./router/router");
const app = express();
require("./db/mongoose");
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true}));
app.use(express.json());
app.use(myRouter);
const PORT = process.env.PORT;
const server = app.listen(PORT, () =>
    console.log(`server running on port ${PORT}`)
    );
    app.get("/",(req, res)=> {
        res.send("Hello")
    })
