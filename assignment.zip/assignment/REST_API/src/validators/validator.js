const joi = require("joi");

const validate = async(req, res, next) => {
    const schema = joi.object({
        username: joi.string().required(),
        password: joi.string().min(6).required(),
        role: joi.string().required()
    });

    try {
        await schema.validateAsync(req.body);
        next();
    } catch (error) {
        throw error;
    }
}
const validateLogin = async(req, res, next) => {
    const schema = joi.object({
        username: joi.string().required(),
        password: joi.string().min(6).required()
    });

    try {
        await schema.validateAsync(req.body);
        next();
    } catch (error) {
        throw error;
    }
}

module.exports = {
    validate,
    validateLogin
}