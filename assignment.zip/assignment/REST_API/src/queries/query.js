const {adminModel} = require("../model/model");
const decoded = require("../middleware/token");

const saveAdminDetails = async(adminDetails) => {
    try {
        const saveAdmin = await new adminModel(adminDetails).save();
        return saveAdmin
    } catch (error) {
        throw error
    }
}

const findAdminByUsername = async(username) => {
    try {
        const admin = await adminModel.findOne({username:username});
        return admin;
    } catch (error) {
        throw error;
    }
}

const viewUsers = async() => {
    try {
        const viewUser = await adminModel.find();
        return viewUser;
    } catch (error) {
        throw error;
    }
}

const deleteUserById = async(id) => {
    try {
        const deleteUser = await adminModel.findByIdAndDelete(id);
        return deleteUser;
    } catch (error) {
        throw error;
    }
}

const viewProfile = async(username) => {
    try {
        const viewedProfile = await adminModel.findOne(username);
        return viewedProfile;
    } catch (error) {
        throw error
        
    }
}
module.exports = {
    saveAdminDetails,
    findAdminByUsername,
    viewUsers,
    deleteUserById,
    viewProfile
}
