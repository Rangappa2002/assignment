const express = require("express")
const router = express.Router();
const controller = require("../controller/controller");
const validator = require("../validators/validator");
const { protect, admin} = require("../middleware/token");
router.post("/register",validator.validate, controller.saveAdminDetails);
router.post("/login",validator.validateLogin, controller.login);
router.get("/users", protect, admin,  controller.viewUsers);
router.delete("/delete/:id", protect, admin, controller.deleteUserById);
router.get("/profile", protect, controller.viewProfile)

module.exports = router;