const jwt = require('jsonwebtoken');
const Admin = require('../model/model');  

const generateToken = (username, role) => {
    return jwt.sign({ id: username, role }, process.env.JWT_SECRET,);
};

const protect = async (req, res, next) => {
    let token;

    if (req.headers.authorization && req.headers.authorization.startsWith('Bearer')) {
        token = req.headers.authorization.split(' ')[1]; 
    }

    if (!token) {
        return "Not Authorized, token missing." 
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        req.user = await Admin.adminModel.findOne({username: decoded.id});
        if (!req.user) {
            return "Admin Not Found."
        }
        
        next(); 
    } catch (error) {
        return "Invalid Token."
    }
};

const admin = (req, res, next) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ message: "Access Denied. Admins only." });
    }
    next(); 
};

module.exports = {
    generateToken,
    protect,
    admin,

};
