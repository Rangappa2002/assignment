const services = require("../services/services");

const saveAdminDetails = async(req, res) => {
    try {
        const result = await services.saveAdminDetails(req.body);
        return res.status(200).send(result);
    } catch (error) {
        console.log(error);
        
        return res.status(404).send(error);
    }
}

const login = async(req, res) => {
    try {
        const result = await services.login(req.body);
        return res.status(200).send(result);
    } catch (error) {
        return res.status(404).send(error);
    }
}

const viewUsers = async(req, res) => {
    try {
        const result = await services.viewUsers(req.body);
        return res.status(200).send(result);
    } catch (error) {
        return res.status(404).send(error);
    }
}

const deleteUserById = async(req, res) => {
    try {
        const result = await services.deleteUserById(req.params.id);
        return res.status(200).send(result);
    } catch (error) {
        return res.status(404).send(error);
    }
}

const viewProfile = async(req, res) => {
    try {
        const user_id=req.params.id;
        const view = req.body;
        const result = await services.viewProfile(user_id, view);
        console.log(result);
        
        return res.status(200).send(result);
    } catch (error) {
        console.log(error);
        
        return res.status(404).send(error);
    }
}

module.exports = {
    saveAdminDetails,
    login,
    viewUsers,
    deleteUserById,
    viewProfile
}