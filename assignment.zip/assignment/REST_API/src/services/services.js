const { generateToken } = require("../middleware/token");
const queries = require("../queries/query");
const bcrypt = require("bcrypt");
const { use } = require("../router/router");

const saveAdminDetails = async(body) => {
    try {
        const {username, password, role} = body;
        const hashPassword = await bcrypt.hash(password, 10);
        const adminDetails = {username,password:hashPassword,role};
        const saveAdmin = await queries.saveAdminDetails(adminDetails);
        return saveAdmin
    } catch (error) {
        throw error;
    }
}

const login = async(body) => {
    try {
        const {username, password} = body;
        const log = await queries.findAdminByUsername(username);
        if(!log){
            return "User or Admin Not Found."
        }
        const checkpassword = await bcrypt.compare(password, log.password);
        if(!checkpassword){
            return "Invalid Password."
        }
        const token = await generateToken(username);
        return token
    } catch (error) {
        throw error;
        
    }
}

const viewUsers = async() => {
    try {
        const viewUser = await queries.viewUsers();
        return viewUser;
    } catch (error) {
        throw error;
    }
}

const deleteUserById = async(id) => {
    try {
        const deleteUser = await queries.deleteUserById(id);
        return deleteUser;
    } catch (error) {
        throw error;
    }
}

const viewProfile = async(username) => {
    try {
        const viewedProfile = await queries.viewProfile(username);
        return viewedProfile;
    } catch (error) {
        throw error;
    }
}

module.exports = {
    saveAdminDetails,
    login,
    viewUsers,
    deleteUserById,
    viewProfile
}